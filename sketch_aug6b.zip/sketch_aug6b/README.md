# SHTC3 Temperature Humidity Sensor Library

>Library sensor SHT3C RS485 Modbus RTU for **boards Arduino**.

![SHTC3_V1](/extras/SHTC3_V1.jfif "SHTC3_V1")

>[SHTC3 Temperature Humidity Sensor IP67 V1 RS485 Modbus RTU](https://hshop.vn/products/cam-bien-do-am-nhiet-do-khong-khi-shtc3-temperature-humidity-sensor-ip67-v1-rs485-modbus-rtu)

![SHTC3_V2](/extras/SHTC3_V2.jfif "SHTC3_V2")

>[SHTC3 Temperature Humidity Sensor V2 RS485 Modbus RTU](https://hshop.vn/products/cam-bien-do-am-nhiet-do-khong-khi-shtc3-temperature-humidity-sensor-v2-rs485-modbus-rtu)

![SHTC3_V3](/extras/SHTC3_V3.jfif "SHTC3_V3")

>[SHTC3 Temperature Humidity Sensor V3 RS485 Modbus RTU](https://hshop.vn/products/cam-bien-do-am-nhiet-do-khong-khi-shtc3-temperature-humidity-sensor-v3-rs485-modbus-rtu)

![SHTC3_V4](/extras/SHTC3_V4.jfif "SHTC3_V4")

>[SHTC3 Temperature Humidity Sensor V4 RS485 Modbus RTU](https://hshop.vn/products/cam-bien-do-am-nhiet-do-khong-khi-shtc3-temperature-humidity-sensor-v4-rs485-modbus-rtu)
