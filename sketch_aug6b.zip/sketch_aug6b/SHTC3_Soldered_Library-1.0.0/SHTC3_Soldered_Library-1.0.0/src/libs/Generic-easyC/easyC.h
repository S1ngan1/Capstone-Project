/**
 **************************************************
 *
 * @file        Generic-easyC-SOLDERED.h
 * @brief       Basic funtions for easyC libraries
 *
 *
 *
 * @authors     @ soldered.com
 ***************************************************/

#ifndef __EASYC_LIBRARY__
#define __EASYC_LIBRARY__

#include "Arduino.h"
#include "Wire.h"

#define ANALOG_READ_REG  0
#define DIGITAL_READ_REG 1

class EasyC
{
  public:
    EasyC();

    void begin();
    void begin(uint8_t _address);

  protected:
    int native = 0;
    bool beginDone = 0;

    virtual void initializeNative() = 0;

    int err;

    char address;
    const char defaultAddress = 0x70;

    int sendAddress(char regAddr);
    int readData(char a[], int n);
    int sendData(char a[], int n);
    int readRegister(char regAddr, char a[], size_t n);
};

#endif
