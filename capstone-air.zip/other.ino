#include <WiFiS3.h>
#include <ArduinoHttpClient.h>
#include <ArduinoJson.h>
#include "FULLSEN.h"

//--- SECRET - FILL IN YOUR DETAILS ---
const char* WIFI_SSID = "use the phone";
const char* WIFI_PASS = "u should know this yourself";
// Supabase details from Project Settings -> API
const char* SUPABASE_URL = "database url";
const int port = 443;
const char* SUPABASE_KEY = "public api key";

//--- END OF SECRET ---

// The name of the table you created in Supabase
const char* SUPABASE_TABLE_NAME = "test";

// Sensor UUIDs for unique identification (SHTC3 removed)
const String PH_SENSOR_UUID = "ph-sensor-001";
const String EC_SENSOR_UUID = "ec-sensor-001";
const String SOIL_SENSOR_UUID = "soil-sensor-001";
const String TEMP_SENSOR_UUID = "temp-sensor-001";

// WiFi and HTTP Client objects
WiFiSSLClient wifi;
HttpClient client = HttpClient(wifi, SUPABASE_URL, 443);

// The built-in LED to show status
const int ledPin = LED_BUILTIN;

// Data collection interval (30 seconds = 30 * 1000 = 30,000 milliseconds)
const unsigned long DATA_COLLECTION_INTERVAL = 30UL * 1000UL; // 30 seconds
unsigned long lastDataCollection = 0;

void setup() {
  Serial.begin(9600);
  while (!Serial)
    ;  // Wait for serial monitor to open

  wifi.setTimeout(30000); // Increased timeout for WiFi operations (30 seconds)
  client = HttpClient(wifi, SUPABASE_URL, 443);
  client.setTimeout(30000); // Set HTTP client timeout

  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, LOW);

  // Initialize sensors
  setupSensors();

  connectToWiFi();
  
  // Initialize the timer
  lastDataCollection = millis();
  Serial.println("Data collection will happen every 30 seconds");
  Serial.println("Next data collection in 30 seconds...");
}

void loop() {
  // Check WiFi connection status
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi connection lost. Reconnecting...");
    connectToWiFi();
  }

  // Check if it's time for data collection (every 30 seconds)
  unsigned long currentTime = millis();
  
  if (currentTime - lastDataCollection >= DATA_COLLECTION_INTERVAL) {
    Serial.println("\n========== 30 SECOND DATA COLLECTION ==========");
    
    // Read sensor data
    readSensors();

    // Create and send multiple JSON payloads - one for each sensor
    sendMultipleSensorPayloads();
    
    // Update the last collection time
    lastDataCollection = currentTime;
    
    Serial.println("Data collection complete. Next collection in 30 seconds...");
    Serial.println("==================================================\n");
  } else {
    // Show remaining time until next collection
    unsigned long remainingTime = DATA_COLLECTION_INTERVAL - (currentTime - lastDataCollection);
    unsigned long remainingSeconds = remainingTime / 1000; // Convert to seconds
    
    // Print status every 30 seconds
    static unsigned long lastStatusPrint = 0;
    if (currentTime - lastStatusPrint >= 30000) { // 30 seconds
      Serial.print("System running. Next data collection in ");
      Serial.print(remainingSeconds);
      Serial.println(" seconds...");
      lastStatusPrint = currentTime;
    }
  }

  // Small delay to prevent excessive loop iterations
  delay(1000); // Check every second
}

void connectToWiFi() {
  Serial.print("Attempting to connect to SSID: ");
  Serial.println(WIFI_SSID);

  while (WiFi.status() != WL_CONNECTED) {
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    digitalWrite(ledPin, HIGH);
    delay(500);
    digitalWrite(ledPin, LOW);
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connected!");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
  digitalWrite(ledPin, HIGH);  // Turn LED on to indicate connection
}

void sendMultipleSensorPayloads() {
  Serial.println("\n========== SENDING MULTIPLE JSON PAYLOADS ==========");
  
  // Create and send pH sensor payload with UUID

  
  // Create and send sen0574 payload
  String s0574Payload = createSingleSensorPayload(SEN0574_UUID, sen0574_value);
  Serial.println("Sending sen0574 data...");
  sendToSupabase(s0574Payload);
  delay(1000);
  
  // Create and send sen0132 payload
  String s0132Payload = createSingleSensorPayload(SEN0132_UUID, sen0132_value);
  Serial.println("Sending sen0132 data...");
  sendToSupabase(s0132Payload);
  delay(1000);
  
  // Create and send sen0567 payload
  String s0567Payload = createSingleSensorPayload(SEN0567_UUID, sen0567_value);
  Serial.println("Sending sen0567 data...");
  sendToSupabase(s0567Payload);
  
  Serial.println("========== ALL PAYLOADS SENT ==========");
}

String createSingleSensorPayload(String sensor_id, float value) {
  // Create single JSON payload with: id, sensor_id, value
  JsonDocument doc;
  
  // Generate a unique ID using timestamp and sensor type
  String uniqueId = sensor_id + "-" + String(millis());
  
  doc["id"] = uniqueId;
  doc["sensor_id"] = sensor_id;
  doc["value"] = value;
  
  String jsonPayload;
  serializeJson(doc, jsonPayload);
  
  Serial.println("JSON Payload: " + jsonPayload);
  
  return jsonPayload;
}
  
  

void sendToSupabase(String payload) {
  String apiPath = "/rest/v1/" + String("sensor_data");

  Serial.print("Making POST request to: ");
  Serial.println(apiPath);

  // Check WiFi connection before making request
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi not connected! Attempting to reconnect...");
    connectToWiFi();
    return;
  }

  // Set longer timeout for SSL connections
  client.setTimeout(30000); // 30 seconds timeout
  
  // Set the required headers for Supabase
  client.beginRequest();
  client.post(apiPath);
  Serial.println("--- REQUEST HEADERS ---");
  Serial.print("apikey: "); Serial.println(SUPABASE_KEY);
  Serial.print("Authorization: Bearer "); Serial.println(SUPABASE_KEY);
  Serial.println("Content-Type: application/json");
  Serial.println("Prefer: return=minimal");
  Serial.print("Content-Length: "); Serial.println(String(payload.length()));
  Serial.println("-----------------------");
  client.sendHeader("apikey", SUPABASE_KEY);
  client.sendHeader("Authorization", "Bearer " + String(SUPABASE_KEY));
  client.sendHeader("Content-Type", "application/json");
  client.sendHeader("Prefer", "return=minimal");  // Ask Supabase not to return the inserted data
  client.sendHeader("Content-Length", String(payload.length()));
  client.beginBody();
  client.print(payload);
  client.endRequest();

  // Read the response with timeout handling
  Serial.println("Waiting for response...");
  unsigned long startTime = millis();
  int statusCode = client.responseStatusCode();
  String responseBody = client.responseBody();

  Serial.print("HTTP Status code: ");
  Serial.println(statusCode);
  Serial.print("Response: ");
  Serial.println(responseBody);
  
  // Enhanced error handling
  if (statusCode == -3) {
    Serial.println("\n--- CONNECTION TIMEOUT ERROR ---");
    Serial.println("Possible causes:");
    Serial.println("1. Network connectivity issues");
    Serial.println("2. Supabase server temporarily unavailable");
    Serial.println("3. SSL/TLS handshake timeout");
    Serial.println("4. Firewall blocking the connection");
    Serial.println("Retrying in next cycle...");
    Serial.println("--------------------------------\n");
  } else if (statusCode == 400) {
    Serial.println("\n--- DEBUG INFO ---");
    Serial.print("Payload sent: ");
    Serial.println(payload);
    Serial.print("API Path: ");
    Serial.println(apiPath);
    Serial.println("Check that your Supabase table and columns match the payload exactly.");
    Serial.println("Check your API key and permissions.");
    Serial.println("------------------\n");
  } else if (statusCode == 201) {  // 201 Created is the success code for insertion
    Serial.println("Data successfully sent to Supabase!");
    // Blink LED on success
    digitalWrite(ledPin, LOW);
    delay(100);
    digitalWrite(ledPin, HIGH);
  } else if (statusCode < 0) {
    Serial.println("\n--- NETWORK ERROR ---");
    Serial.print("Error code: ");
    Serial.println(statusCode);
    Serial.println("Network or connection issue detected.");
    Serial.println("--------------------\n");
  } else {
    Serial.println("Error sending data to Supabase.");
  }
}