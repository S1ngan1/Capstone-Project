// FULLSEN.h - Sensor definitions

#ifndef FULLSEN_H
#define FULLSEN_H

#include <Arduino.h>

// New sensor UUIDs
const String SEN0574_UUID = "sen0574";
const String SEN0132_UUID = "sen0132";
const String SEN0567_UUID = "sen0567";

// Sensor pin definitions
#define SEN0574_PIN A3  // TDS Sensor
#define SEN0132_PIN A4  // CO Gas Sensor
#define SEN0567_PIN A5  // NH3 Gas Sensor

// Sensor value variables
float sen0574_value = 0.0f;  // TDS in ppm
float sen0132_value = 0.0f;  // CO in ppm
float sen0567_value = 0.0f;  // NH3 in ppm

// Existing sensor variables
float ecValue = 0.0f;
float soilMoistureValue = 0.0f;
float temperature = 25.0f;

// Setup sensors
void setupSensors() {
  // Initialize analog pins for reading
  pinMode(SEN0574_PIN, INPUT);
  pinMode(SEN0132_PIN, INPUT);
  pinMode(SEN0567_PIN, INPUT);
}

// Read sensors
void readSensors() {
  // Read SEN0574 - TDS Sensor (Gravity TDS)
  int tdsRawValue = analogRead(SEN0574_PIN);
  sen0574_value = (float)tdsRawValue; // Convert to actual TDS ppm based on calibration
  
  // Read SEN0132 - MQ-7 CO Gas Sensor
  int coRawValue = analogRead(SEN0132_PIN);
  sen0132_value = (float)coRawValue; // Convert to CO ppm based on calibration
  
  // Read SEN0567 - MEMS NH3 Sensor
  int nh3RawValue = analogRead(SEN0567_PIN);
  sen0567_value = (float)nh3RawValue; // Convert to NH3 ppm based on calibration
}

#endif
